package com.example.gluong.stopwatch;

import android.os.Handler;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.Format;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class MainActivity extends AppCompatActivity {
/*
    private long startTime = System.nanoTime();
    private boolean run = false;

    private final ReentrantLock lock = new ReentrantLock();
    private final Condition runStopWatch = lock.newCondition();

    private Thread thread;
    private Thread currentThread = Thread.currentThread();
    private TextView timeDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button start = (Button) findViewById(R.id.startButton);
        Button stop = (Button) findViewById(R.id.stopButton);
        timeDisplay = (TextView) findViewById(R.id.timeDisplay);

        thread = new Thread(() -> {
            try {
                lock.lock();

                try {
                    runStopWatch.await();

                    while (!Thread.interrupted()) {
                        if (run) {
                            updateStopwatch(timeDisplay);
                        } else
                            runStopWatch.await();
                    }
                } finally {
                    lock.unlock();
                }

            } catch (InterruptedException e) {
                return;
            }
        });

        start.setOnClickListener(v -> {
            lock.lock();

            try {
                startTime = System.nanoTime();
                run = true;
                runStopWatch.signal();
            } finally {
                lock.unlock();
            }
        });

        stop.setOnClickListener(v -> {
            lock.lock();

            try {
                run = false;
            } finally {
                lock.unlock();
            }
        });

        thread.start();
    }

    private void updateStopwatch(TextView textView) {
        textView.setText("" + (System.nanoTime() - startTime));
    }
    */


    private Handler handler;
    private boolean isRunning;
    private long startTime = 0;
    private Runnable refresh = () -> {
        update();
        if (isRunning)
            handler.postDelayed(this.refresh, 500);
    };

    private void update() {
        long time = (System.nanoTime() - startTime) / 1_000_000_000;
        ((TextView) findViewById(R.id.timeDisplay)).setText(time/60 + " : "  + time%60);
    }

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        if (b != null) {
            startTime = b.getLong("startTime");
            isRunning = b.getBoolean("active");
        }

        handler = new Handler();

        Button start = (Button) findViewById(R.id.startButton);
        Button stop = (Button) findViewById(R.id.stopButton);

        start.setOnClickListener(v -> {
            isRunning = true;
            startTime = System.nanoTime();
            handler.post(refresh);
        });

        stop.setOnClickListener(v -> {
            isRunning = false;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(refresh);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(refresh);
    }

    @Override
    protected void onSaveInstanceState(Bundle b) {
        super.onSaveInstanceState(b);
        b.putLong("startTime", startTime);
        b.putBoolean("active", isRunning);
    }
}
