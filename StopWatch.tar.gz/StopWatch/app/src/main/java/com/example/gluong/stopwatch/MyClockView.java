package com.example.gluong.stopwatch;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

/**
 * Created by gluong on 19/10/17.
 */

public class MyClockView extends View {
    private long elapsedTime;

    public MyClockView(Context context) {
        super(context);
    }

    public void setElapsedTime (int time) {
        elapsedTime = time;
        invalidate();
    }

    public void onDraw (Canvas c) {

    }
}
